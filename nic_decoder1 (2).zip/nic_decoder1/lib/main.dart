import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

void main() {
  runApp(const NICDecoderApp());
}

class NICDecoderApp extends StatelessWidget {
  const NICDecoderApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.green,
        scaffoldBackgroundColor: Colors.green.shade200,
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.green,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 35),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          ),
        ),
      ),
      home: const InputScreen(),
    );
  }
}

class InputScreen extends StatefulWidget {
  const InputScreen({super.key});

  @override
  _InputScreenState createState() => _InputScreenState();
}

class _InputScreenState extends State<InputScreen> {
  final TextEditingController _controller = TextEditingController();

  /// Function to validate and decode the NIC number
  void _decodeNIC() {
    String nic = _controller.text.trim();
    if (nic.isEmpty || (nic.length != 10 && nic.length != 12)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a valid NIC number')),
      );
      return;
    }
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => ResultScreen(nic: nic)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('NIC Decoder'), backgroundColor: Colors.lightGreen),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            /// Input field for entering NIC number
            TextField(
              controller: _controller,
              decoration: InputDecoration(
                labelText: 'Enter NIC Number',
                prefixIcon: const Icon(FontAwesomeIcons.idCard),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                filled: true,
                fillColor: Colors.white,
              ),
            ),
            const SizedBox(height: 20),

            /// Decode button
            ElevatedButton.icon(
              onPressed: _decodeNIC,
              icon: const Icon(FontAwesomeIcons.search),
              label: const Text('Decode'),
            ),
          ],
        ),
      ),
    );
  }
}

class ResultScreen extends StatelessWidget {
  final String nic;
  const ResultScreen({super.key, required this.nic});

  /// Function to decode NIC details
  Map<String, dynamic> decodeNIC(String nic) {
    bool isOldFormat = nic.length == 10;
    String year = isOldFormat ? '19${nic.substring(0, 2)}' : nic.substring(0, 4);
    int dayOfYear = int.parse(nic.substring(isOldFormat ? 2 : 5, isOldFormat ? 5 : 7));
    bool isFemale = dayOfYear > 500;
    if (isFemale) dayOfYear -= 500;

    // Calculate date of birth from year and day of year
    DateTime dob = DateTime(int.parse(year), 1, 1).add(Duration(days: dayOfYear - 1));
    String weekday = DateFormat('EEEE').format(dob);
    int age = DateTime.now().year - dob.year;
    String gender = isFemale ? 'Female' : 'Male';
    String voteAbility = (isOldFormat && nic[9].toUpperCase() == 'X') ? 'No' : 'Yes';

    return {
      'DOB': DateFormat('yyyy-MM-dd').format(dob),
      'Weekday': weekday,
      'Age': age,
      'Gender': gender,
      'Can Vote': voteAbility,
    };
  }

  @override
  Widget build(BuildContext context) {
    Map<String, dynamic> result = decodeNIC(nic);
    return Scaffold(
      appBar: AppBar(title: const Text('NIC Details'), backgroundColor: Colors.lightGreen),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            /// Displaying the decoded NIC details in a card
            Card(
              color: Colors.white,
              elevation: 5,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              child: Padding(
                padding: const EdgeInsets.all(15.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: result.entries.map((entry) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 20),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              /// Icon representation for Gender and Date
                              Icon(entry.key == 'Gender' ? FontAwesomeIcons.venusMars : FontAwesomeIcons.calendarDay),
                              const SizedBox(width: 20),
                              Text(entry.key, style: const TextStyle(fontWeight: FontWeight.bold)),
                            ],
                          ),
                          Text(entry.value.toString()),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              ),
            ),
            const SizedBox(height: 50),
            /// Back button to return to the input screen
            Center(
              child: ElevatedButton.icon(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(FontAwesomeIcons.arrowLeft),
                label: const Text('Back'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
